##《专为设计师而写的GitHub快速入门教程》案例仓库

这是一篇专为设计师而写的GitHub教程中用到的案例素材，可以[点这里](http://www.ui.cn/project.php?id=20957)在UI中国看到全文。
